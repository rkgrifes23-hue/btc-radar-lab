// Teste offline das funções de interpretação, ordenação e prioridade dos candles.
const fs=require('fs');
const vm=require('vm');
const assert=require('assert');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
let script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
script=script.replace(/\ndrawChart\(\);\nstart\(\);\s*$/, '\n');
const nodes=new Map();
function stub(id) {
  if (nodes.has(id)) return nodes.get(id);
  const obj={textContent:'',className:'',disabled:false,clientWidth:800,clientHeight:350,
    parentElement:{clientWidth:800,clientHeight:350},
    addEventListener:()=>{},replaceChildren:()=>{},getContext:()=>null};
  nodes.set(id,obj);return obj;
}
const context={
  console, Date, Intl, Math, Number, String, Error, Array,
  structuredClone, setInterval:()=>{},clearInterval:()=>{},setTimeout:()=>{},clearTimeout:()=>{},
  document:{getElementById:stub,createElement:()=>({textContent:''})},
  window:{addEventListener:()=>{},devicePixelRatio:1},
};
vm.createContext(context);
vm.runInContext(script,context,{timeout:2000});
const result=vm.runInContext('runChecks()',context,{timeout:2000});
assert.strictEqual(result.passed,6);
assert.strictEqual(result.failed,0);
assert.strictEqual(stub('checkResult').textContent.includes('6 verificações aprovadas'),true);
console.log('AUTOTESTE APROVADO:',JSON.stringify(result));
